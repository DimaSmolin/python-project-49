 #!/usr/bin/env py

def main():
    print('Welcome to the Brain Games!')


if __name__ == '__main__':
    main()
